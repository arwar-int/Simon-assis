package com.simon.assistant

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * Невидимая активность — запускается из уведомления/оверлея,
 * сразу включает прослушивание команды и закрывается.
 */
class VoiceActivity : Activity() {

    private lateinit var engine: SimonEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = SimonEngine(this)
        engine.callback = object : SimonEngine.Callback {
            override fun onResult(spoken: String, answer: String) { finishLater() }
            override fun onError(message: String) {
                engine.speak(message); finishLater()
            }
        }

        if (hasMicPermission()) {
            // небольшая задержка, чтобы TTS успел инициализироваться
            Handler(Looper.getMainLooper()).postDelayed({ engine.startListening() }, 250)
        } else {
            engine.speak("Нет доступа к микрофону. Откройте приложение Саймон и выдайте разрешение.")
            finishLater()
        }
    }

    private fun hasMicPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
    }

    private fun finishLater() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) finish()
        }, 3500)
    }

    override fun onDestroy() {
        engine.shutdown()
        super.onDestroy()
    }
}
