package com.simon.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.app.Activity

class MainActivity : Activity() {

    private lateinit var engine: SimonEngine
    private lateinit var log: TextView
    private lateinit var status: TextView
    private var greeted = false

    private val REQ_PERMS = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        log = findViewById(R.id.log)
        status = findViewById(R.id.status)
        log.movementMethod = ScrollingMovementMethod()

        engine = SimonEngine(this)
        engine.callback = object : SimonEngine.Callback {
            override fun onListeningStart() { runOnUiThread { status.text = "Слушаю…" } }
            override fun onPartial(text: String) { runOnUiThread { status.text = "…$text" } }
            override fun onResult(spoken: String, answer: String) {
                runOnUiThread {
                    status.text = "Готов"
                    append("Вы: $spoken")
                    append("Саймон: $answer")
                }
            }
            override fun onError(message: String) {
                runOnUiThread { status.text = "Готов"; append("⚠ $message") }
            }
        }

        findViewById<Button>(R.id.btnListen).setOnClickListener { ensureMicThenListen() }
        findViewById<Button>(R.id.btnSend).setOnClickListener {
            val et = findViewById<EditText>(R.id.input)
            val txt = et.text.toString()
            if (txt.isNotBlank()) { engine.processText(txt); et.setText("") }
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener { requestOverlay() }
        findViewById<Button>(R.id.btnService).setOnClickListener { startSimonService() }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestIgnoreBattery() }

        requestRuntimePermissions()
        startSimonService()
    }

    override fun onResume() {
        super.onResume()
        if (!greeted) {
            greeted = true
            Handler(Looper.getMainLooper()).postDelayed({
                engine.speak("Саймон к вашим услугам")
                append("Саймон: Саймон к вашим услугам")
            }, 700)
        }
    }

    private fun ensureMicThenListen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_PERMS)
            return
        }
        engine.startListening()
    }

    private fun append(line: String) {
        log.append(if (log.text.isEmpty()) line else "\n$line")
    }

    // -------- разрешения / сервисы --------
    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), REQ_PERMS)
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } else {
            append("Оверлей уже разрешён.")
            startSimonService()
        }
    }

    private fun requestIgnoreBattery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun startSimonService() {
        val i = Intent(this, SimonService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
    }

    override fun onDestroy() {
        engine.shutdown()
        super.onDestroy()
    }
}
