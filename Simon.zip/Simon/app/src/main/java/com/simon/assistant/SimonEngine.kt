package com.simon.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

/**
 * Единый "мозг" Саймона: распознавание речи (RU) + синтез речи + обработка команд.
 * Используется и из MainActivity, и из быстрого запуска (VoiceActivity).
 */
class SimonEngine(private val ctx: Context) : TextToSpeech.OnInitListener {

    interface Callback {
        fun onListeningStart() {}
        fun onPartial(text: String) {}
        fun onResult(spoken: String, answer: String) {}
        fun onError(message: String) {}
    }

    private var tts: TextToSpeech? = TextToSpeech(ctx.applicationContext, this)
    private var recognizer: SpeechRecognizer? = null
    private val processor = CommandProcessor(ctx.applicationContext)
    var callback: Callback? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "simon")
    }

    /** Запускает разовое прослушивание команды. */
    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            val msg = "Распознавание речи недоступно на устройстве."
            callback?.onError(msg)
            speak(msg)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        callback?.onListeningStart()
        recognizer?.startListening(intent)
    }

    /** Обрабатывает уже готовый текст (например, набранный руками). */
    fun processText(text: String) {
        val cleaned = stripWakeWord(text)
        val answer = processor.handle(cleaned)
        toast(answer)
        speak(answer)
        callback?.onResult(text, answer)
    }

    private fun stripWakeWord(text: String): String {
        var t = text.trim()
        val lower = t.lowercase()
        for (w in listOf("саймон,", "саймон", "симон,", "симон")) {
            if (lower.startsWith(w)) { t = t.substring(w.length).trim(); break }
        }
        return t
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "Не расслышал, повторите."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Тишина. Я не услышал команды."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Проблема с сетью для распознавания."
                else -> "Ошибка распознавания."
            }
            callback?.onError(msg)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            list?.firstOrNull()?.let { callback?.onPartial(it) }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = list?.firstOrNull()?.trim().orEmpty()
            if (text.isEmpty()) {
                callback?.onError("Команда не распознана.")
                return
            }
            processText(text)
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(ctx.applicationContext, "Саймон: $msg", Toast.LENGTH_SHORT).show()
    }

    fun shutdown() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
