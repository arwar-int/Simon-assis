package com.simon.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView

/**
 * Foreground service: держит постоянное уведомление в шторке с кнопкой "Слушать"
 * и (если есть разрешение SYSTEM_ALERT_WINDOW) рисует плавающую кнопку-оверлей.
 */
class SimonService : Service() {

    companion object {
        const val CHANNEL_ID = "simon_channel"
        const val NOTIF_ID = 7
        const val ACTION_LISTEN = "com.simon.assistant.LISTEN"
        const val ACTION_STOP = "com.simon.assistant.STOP"
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        addOverlayIfAllowed()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LISTEN -> launchVoice()
            ACTION_STOP -> {
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun launchVoice() {
        val i = Intent(this, VoiceActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    // ---------------- Уведомление ----------------
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Саймон", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Быстрый доступ к голосовому помощнику" }
            nm.createNotificationChannel(channel)
        }

        val listenIntent = PendingIntent.getService(
            this, 1,
            Intent(this, SimonService::class.java).setAction(ACTION_LISTEN),
            pendingFlags()
        )
        val openIntent = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java),
            pendingFlags()
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)

        return builder
            .setContentTitle("Саймон готов")
            .setContentText("Нажмите, чтобы дать команду голосом")
            .setSmallIcon(R.drawable.ic_simon)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(R.drawable.ic_mic, "Слушать", listenIntent)
            .build()
    }

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

    // ---------------- Оверлей ----------------
    private fun addOverlayIfAllowed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
        if (overlayView != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 300
        }

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_button, null)
        val btn = view.findViewById<ImageView>(R.id.overlayMic)

        // Перетаскивание + клик
        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    touchX = e.rawX; touchY = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    params.x = initX + dx; params.y = initY + dy
                    windowManager?.updateViewLayout(view, params); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) launchVoice()
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(view, params)
            overlayView = view
        } catch (e: Exception) { e.printStackTrace() }
    }

    override fun onDestroy() {
        overlayView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        overlayView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
