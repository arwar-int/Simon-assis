package com.simon.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent

/**
 * Разбирает распознанный текст и превращает его в действия.
 * Возвращает текстовый ответ, который нужно произнести/показать.
 */
class CommandProcessor(private val ctx: Context) {

    /** Главная точка входа. raw — это уже текст БЕЗ слова "Саймон". */
    fun handle(raw: String): String {
        val text = raw.trim().lowercase()
        if (text.isEmpty()) return "Я вас не расслышал."

        // --- Управление музыкой ---
        when {
            matches(text, "включи музыку", "играй музыку", "продолжи музыку", "плей", "воспроизведи") -> {
                media(KeyEvent.KEYCODE_MEDIA_PLAY); return "Включаю музыку."
            }
            matches(text, "выключи музыку", "останови музыку", "пауза", "стоп", "поставь на паузу") -> {
                media(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Ставлю на паузу."
            }
            matches(text, "следующий трек", "следующая песня", "переключи вперёд", "следующий", "дальше") -> {
                media(KeyEvent.KEYCODE_MEDIA_NEXT); return "Следующий трек."
            }
            matches(text, "предыдущий трек", "предыдущая песня", "назад трек", "предыдущий") -> {
                media(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Предыдущий трек."
            }
            matches(text, "поставь на повтор", "повтор", "повторяй", "режим повтора") -> {
                // На системном уровне нет глобальной клавиши repeat — открываем плеер и сообщаем.
                return "Включаю повтор в плеере, если он поддерживает медиакнопки. Повтор обычно настраивается в самом плеере."
            }
        }

        // --- Громкость ---
        when {
            matches(text, "громче", "сделай громче", "прибавь звук", "увеличь громкость") -> {
                volume(true); return "Прибавляю громкость."
            }
            matches(text, "тише", "сделай тише", "убавь звук", "уменьши громкость") -> {
                volume(false); return "Убавляю громкость."
            }
            matches(text, "выключи звук", "без звука", "беззвучный", "отключи звук") -> {
                mute(); return "Отключаю звук."
            }
        }

        // --- Поиск на YouTube (проверяем раньше браузера) ---
        youtubeQuery(text)?.let { q ->
            openYoutube(q); return "Ищу «$q» на Ютубе."
        }

        // --- Поиск в интернете ---
        webQuery(text)?.let { q ->
            openWeb(q); return "Ищу «$q» в интернете."
        }

        // --- Открытие приложений ---
        appQuery(text)?.let { name ->
            return openApp(name)
        }

        // --- Прочее: локальный ИИ-ответ (заглушка) ---
        return LocalAI.reply(raw.trim())
    }

    private fun matches(text: String, vararg variants: String): Boolean =
        variants.any { text == it || text.startsWith("$it ") || text.endsWith(" $it") || text.contains(" $it ") || (variants.size == 1 && text.contains(it)) }

    // ---------- Музыка / громкость ----------
    private fun media(keyCode: Int) {
        MediaController.sendKey(ctx, keyCode)
    }

    private fun volume(increase: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun mute() {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
    }

    // ---------- YouTube ----------
    private fun youtubeQuery(text: String): String? {
        val markers = listOf("на ютубе", "на ютуб", "на youtube", "в ютубе", "в ютуб")
        // формат: "найди X на ютубе" / "включи X на ютубе"
        for (m in markers) {
            if (text.contains(m)) {
                var q = text
                for (p in listOf("найди", "найти", "поищи", "включи", "открой", "запусти")) {
                    if (q.startsWith("$p ")) { q = q.substring(p.length + 1); break }
                }
                q = q.replace(m, "").trim()
                if (q.isNotEmpty()) return q
            }
        }
        return null
    }

    private fun openYoutube(query: String) {
        val enc = Uri.encode(query)
        // Пытаемся открыть в приложении YouTube
        val app = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            ctx.startActivity(app)
        } catch (e: Exception) {
            val web = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=$enc")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            ctx.startActivity(web)
        }
    }

    // ---------- Веб-поиск ----------
    private fun webQuery(text: String): String? {
        val triggers = listOf(
            "найди в интернете", "найти в интернете", "поищи в интернете",
            "найди в гугле", "найди в гугл", "загугли", "погугли"
        )
        for (t in triggers) {
            if (text.startsWith(t)) return text.removePrefix(t).trim().ifEmpty { null }
            if (text.contains(t)) return text.replace(t, "").trim().ifEmpty { null }
        }
        // формат "найди X в интернете"
        if (text.contains("в интернете") || text.contains("в гугле") || text.contains("в гугл")) {
            var q = text
            for (p in listOf("найди", "найти", "поищи", "поиск")) {
                if (q.startsWith("$p ")) { q = q.substring(p.length + 1); break }
            }
            q = q.replace("в интернете", "").replace("в гугле", "").replace("в гугл", "").trim()
            if (q.isNotEmpty()) return q
        }
        return null
    }

    private fun openWeb(query: String) {
        val enc = Uri.encode(query)
        val i = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=$enc")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        ctx.startActivity(i)
    }

    // ---------- Открытие приложений ----------
    private fun appQuery(text: String): String? {
        for (p in listOf("открой ", "запусти ", "открыть ", "включи приложение ", "открой приложение ")) {
            if (text.startsWith(p)) return text.substring(p.length).trim()
        }
        return null
    }

    private fun openApp(spokenName: String): String {
        val pm = ctx.packageManager
        val target = spokenName.lowercase().trim()

        // Известные синонимы -> пакеты
        val known = mapOf(
            "ютуб" to "com.google.android.youtube",
            "youtube" to "com.google.android.youtube",
            "телеграм" to "org.telegram.messenger",
            "телеграмм" to "org.telegram.messenger",
            "ватсап" to "com.whatsapp",
            "вотсап" to "com.whatsapp",
            "whatsapp" to "com.whatsapp",
            "вконтакте" to "com.vkontakte.android",
            "вк" to "com.vkontakte.android",
            "инстаграм" to "com.instagram.android",
            "хром" to "com.android.chrome",
            "браузер" to "com.android.chrome",
            "карты" to "com.google.android.apps.maps",
            "гугл карты" to "com.google.android.apps.maps",
            "камера" to null, // обработаем по системе ниже
            "настройки" to "com.android.settings",
            "ютьюб" to "com.google.android.youtube",
            "плеймаркет" to "com.android.vending",
            "play market" to "com.android.vending",
            "google play" to "com.android.vending"
        )

        known[target]?.let { pkg ->
            launchPackage(pkg)?.let { return it }
        }

        // Поиск по списку установленных приложений по совпадению названия
        val apps = pm.getInstalledApplications(0)
        var best: String? = null
        for (app in apps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label == target) { best = app.packageName; break }
            if (best == null && (label.contains(target) || target.contains(label) && label.length > 3)) {
                best = app.packageName
            }
        }
        if (best != null) {
            launchPackage(best)?.let { return it }
        }
        return "Не нашёл приложение «$spokenName»."
    }

    private fun launchPackage(pkg: String): String? {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return null
        launch.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return try {
            ctx.startActivity(launch)
            val name = try {
                ctx.packageManager.getApplicationLabel(
                    ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            "Открываю $name."
        } catch (e: Exception) { null }
    }
}
