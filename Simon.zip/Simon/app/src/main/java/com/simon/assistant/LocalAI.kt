package com.simon.assistant

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Локальный «ИИ»-ответчик (заглушка, работает офлайн).
 * Обрабатывает простые вопросы, иначе выдаёт нейтральный ответ.
 */
object LocalAI {

    fun reply(input: String): String {
        val t = input.lowercase().trim()

        // Приветствия
        if (any(t, "привет", "здравствуй", "хай", "доброе утро", "добрый день", "добрый вечер")) {
            return "Здравствуйте! Чем могу помочь?"
        }
        if (any(t, "как тебя зовут", "кто ты", "как звать")) {
            return "Меня зовут Саймон. Я ваш голосовой помощник."
        }
        if (any(t, "как дела", "как ты")) {
            return "У меня всё отлично, готов выполнять команды."
        }
        if (any(t, "спасибо", "благодарю")) {
            return "Всегда пожалуйста!"
        }
        if (any(t, "что ты умеешь", "твои возможности", "помощь", "команды")) {
            return "Я умею открывать приложения, управлять музыкой и громкостью, " +
                   "искать в интернете и на Ютубе. Скажите, например: «открой Телеграм», " +
                   "«включи музыку», «следующий трек», «громче», «найди погоду в интернете», " +
                   "«найди музыку на Ютубе»."
        }

        // Время и дата
        if (any(t, "который час", "сколько времени", "время сейчас", "текущее время")) {
            val now = SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
            return "Сейчас $now."
        }
        if (any(t, "какое сегодня число", "какая дата", "какой сегодня день", "число сегодня")) {
            val now = SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date())
            return "Сегодня $now."
        }
        if (any(t, "какой день недели")) {
            val days = arrayOf("воскресенье", "понедельник", "вторник", "среда",
                "четверг", "пятница", "суббота")
            val d = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
            return "Сегодня ${days[d]}."
        }

        // Простая арифметика
        calc(t)?.let { return it }

        return "Извините, для развёрнутых ответов нужен онлайн-ИИ. " +
               "Сейчас я работаю в автономном режиме. Я могу открывать приложения, " +
               "управлять музыкой и искать в интернете."
    }

    private fun any(t: String, vararg keys: String) = keys.any { t.contains(it) }

    private fun calc(t: String): String? {
        // Очень простой парсер: "сколько будет 2 плюс 2"
        val cleaned = t.replace("сколько будет", "")
            .replace("посчитай", "")
            .replace("плюс", "+").replace("минус", "-")
            .replace("умножить на", "*").replace("разделить на", "/")
            .replace("умножить", "*").replace("разделить", "/")
            .replace(",", ".").trim()
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*(-?\\d+(?:\\.\\d+)?)").find(cleaned) ?: return null
        return try {
            val a = m.groupValues[1].toDouble()
            val op = m.groupValues[2]
            val b = m.groupValues[3].toDouble()
            val r = when (op) {
                "+" -> a + b; "-" -> a - b; "*" -> a * b; "/" -> if (b == 0.0) return "На ноль делить нельзя." else a / b
                else -> return null
            }
            val out = if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
            "Получается $out."
        } catch (e: Exception) { null }
    }
}
