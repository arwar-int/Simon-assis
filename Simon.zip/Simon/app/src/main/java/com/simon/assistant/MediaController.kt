package com.simon.assistant

import android.content.Context
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent

/**
 * Отправляет медиа-клавиши активному медиаплееру через AudioManager.
 * Это стандартный способ управлять Play/Pause/Next/Previous без root.
 */
object MediaController {

    fun sendKey(ctx: Context, keyCode: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val event = SystemClock.uptimeMillis()
        val down = KeyEvent(event, event, KeyEvent.ACTION_DOWN, keyCode, 0)
        val up = KeyEvent(event, event, KeyEvent.ACTION_UP, keyCode, 0)
        try {
            am.dispatchMediaKeyEvent(down)
            am.dispatchMediaKeyEvent(up)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
