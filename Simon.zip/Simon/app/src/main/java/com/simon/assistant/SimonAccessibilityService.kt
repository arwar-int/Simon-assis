package com.simon.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility Service для Саймона.
 * Позволяет выполнять глобальные действия (домой, назад, шторка),
 * а также служит "разрешением" для расширенного управления системой.
 *
 * Медиакнопки реализованы через AudioManager (см. MediaController),
 * что не требует Accessibility, но сервис оставлен для глобальных жестов
 * и потенциального расширения (нажатие кнопок в плеере и т.п.).
 */
class SimonAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: SimonAccessibilityService? = null

        const val ACTION_GLOBAL = "com.simon.assistant.GLOBAL_ACTION"
        const val EXTRA_ACTION = "action_id"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* не используется */ }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    /** Удобные обёртки для глобальных действий. */
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
}
